import React, { Component} from 'react';
import { Switch, Route } from 'react-router-dom';

import FormRegistration from './FormRegistration';

class Routes extends Component {
    render(){
        return(
            <Switch>
              <Redirect from="http://localhost:3000/FormRegistration" to="/FormRegistration"/> 
            </Switch>

        )
    }
}