import React from 'react';
import { BrowserRouter, Route } from 'react-router-dom';
import './App.css';
import './Autoanmeldung_styles.css';
import './Responsive_styles.css';
import Home from './components/Home';
import Registration from './components/Registration';


function App() {
  return (
    <div className="App">
      <BrowserRouter>
      <Route path="/" exact component={Home}/>
        <Route path="/Registration" component={Registration}/>
      </BrowserRouter>      
    </div>

      

  );
}

export default App;
