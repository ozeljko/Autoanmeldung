import React from 'react';
import { BrowserRouter, Route } from 'react-router-dom';
import './App.css';
import './Autoanmeldung_styles.css';
import './Responsive_styles.css';
import './Listing_styles.css';
import Home from './components/Home';
import Registration from './components/Registration';
import Listing from './components/Listing';
// /Import Firestore database
import { useEffect } from 'react';
import { collection, doc, onSnapshot } from '@firebase/firestore';
import db from './firebase';



function App() {

  

  return (
    <div className="App">
      <BrowserRouter>
      <Route path="/" exact component={Home}/>
        <Route path="/Registration" component={Registration}/>
        <Route path="/Listing" component={Listing}/>
      </BrowserRouter>      
    </div>

      

  );
}

export default App;
