// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
import { getFirestore} from "firebase/firestore";
import { getAnalytics } from "firebase/analytics";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
  apiKey: "AIzaSyDnY4reWji6FU9S7W3WsucyrGxisqEV8Uw",
  authDomain: "autoanmeldung-project.firebaseapp.com",
  databaseURL: "https://autoanmeldung-project-default-rtdb.europe-west1.firebasedatabase.app",
  projectId: "autoanmeldung-project",
  storageBucket: "autoanmeldung-project.appspot.com",
  messagingSenderId: "439107695587",
  appId: "1:439107695587:web:3c0c7fa14e78a4613c66d6",
  measurementId: "G-NJM8VQNE10"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
export default getFirestore();
const analytics = getAnalytics(app);
