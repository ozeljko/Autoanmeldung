import React from 'react';
import {
    BrowserRouter as Router,    
    Link
  } from "react-router-dom";
import { useHistory } from "react-router-dom";
  

function Home() {

    const history = useHistory();

    const routeChangeRegistration = () =>{ 
      let path = '/Registration'; 
      history.push(path);
    }

    const routeChangeListing = () =>{ 
      let path = '/Listing'; 
      history.push(path);
    }

   

  

  return (
    <div>    
        <div className='split-pane col-xs-12 col-sm-6 registration-side'>
         <div>    
            <div className='text-content'>
                <div className="bold">Auto</div>
                <div className='big'>REGISTRATION</div>
            </div>
            <Router>
            
            <Link to="Registration">
            <button className='button' type="button" onClick={routeChangeRegistration}>
                I want to registrate Car
            </button>
            </Link>
                       
            </Router>
        </div>
        </div>
        <div className='split-pane col-xs-12 col-sm-6 list-side'>
        <div>    
            <div className='text-content'>
            <div className="bold">See</div>
            <div className='big'>All registrated Auto's</div>
            </div>
            <Router>
            <Link to="/Listing">
            <button className='button' type="button" onClick={routeChangeListing}>
                Show me list
            </button>
            </Link>            
            </Router>
        </div>
        </div>
    </div>

    
        
  );
}

export default Home;