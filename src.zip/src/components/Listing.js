import React, { Component} from 'react';
// /Import Firestore database
///import db from '../methodes/firebase';




class Listing extends Component {
  
 
  render(){
    return (
      <>    
          <div className='container'>
              Hello from Listing
          </div>
      </>

      
          
    )
  }
}

export default Listing;