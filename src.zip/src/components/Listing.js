import React, { Component} from 'react';

// /Import Firestore database
import { useEffect, useState } from 'react';
import { collection, doc, onSnapshot, setDoc } from '@firebase/firestore';
import db from '../firebase';




const Listing = () => {
  
  const[Cars, setCars] = useState([]);

  //console.log(Cars);
  
  
  useEffect(
    () =>    
    onSnapshot(collection(db,"Cars"),(snapshot) => 
     setCars(snapshot.docs.map((doc) => ({...doc.data(), id: doc.id})))
    ),
  []
  ); 
  
    return (
      <> 
      
         
    <div className='container'>        
    
    <main className="grid">
    {Cars.map((car) => (
               
    <article>
    <div className="image_auto"><p>Info</p></div>
  <table className="table">
    <div className="text">
    <thead scope="col" className="table-light" >  
      <h3> {car.brand} </h3>
    </thead>      
  <tbody className="table-dark">
      <tr><td>Year: {car.year}</td></tr>
      <tr><td>Cubics: {car.cubics}</td></tr>
      <tr><td>Power (KS): {car.power}</td></tr>
      <tr><td>Drive: {car.drive}</td></tr>
      <tr><td>Gear: {car.gear}</td></tr>
      <tr><td>Lenght: {car.lenght}</td></tr>
      <tr><td>Weight: {car.weight}</td></tr>
  </tbody>
    </div>
    </table>
    </article>
    ))}
    
    </main>
    </div>    
      
      </>   
    );
    
}



export default Listing;



