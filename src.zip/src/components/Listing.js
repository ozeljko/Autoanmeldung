import React, { Component} from 'react';

// /Import Firestore database
import { useEffect, useState } from 'react';
import { collection, doc, onSnapshot, setDoc } from '@firebase/firestore';
import db from '../firebase';




const Listing = () => {
  
  const[Cars, setCars] = useState([]);

  console.log(Cars);
  
  useEffect(
    () =>    
    onSnapshot(collection(db,"Cars"),(snapshot) => 
     setCars(snapshot.docs.map((doc) => ({...doc.data(), id: doc.id})))
    ),
  []
  );   

    return (
      <>    
    <div className='container'>        
    
    <main class="grid">
    {Cars.map((car) => (         
    <article>
    <div className="image_auto"><p>Auto</p></div>
    <div class="text">

      <h3>{car.brand}</h3>
           
      <p>{car.year}</p>
      <p>{car.cubics}</p>
      <p>{car.power}</p>
      <p>{car.drive}</p>
      <p>{car.gear}</p>
      <p>{car.lenght}</p>
      <p>{car.weight}</p>
            
    </div>
    </article>
    ))}
    </main>
    </div>    
      
      </>   
    );
  
}



export default Listing;



