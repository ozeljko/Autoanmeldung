import React, { Component} from 'react';
import FormFieldsRegistration from '../methodes/formFieldsRegistration';
import {validate} from '../methodes/validate';

// /Import Firestore database
import { useEffect, useState } from 'react';
import { collection, doc, onSnapshot, addDoc, FieldValue } from '@firebase/firestore';
import db from '../firebase';




class Registration extends Component {
  
  state = {
    loading: false,
    formData: {
      brand:{
        element:'select',
        value:'',
        config:{
          name:'brand_input'
        },
        validation:{
          required:true
        },
        valid:false,
        touched:false,
        validationMessage:''
      },
      year:{
        element:'input',
        value:'',        
        config:{
            name:'year_input',
            type:'',          
            placeholder:'year of vehicle production',
            maxLength: '4'
                      
        },
        validation:{
            required:true
        },
        valid:false,
        touched: false,
        validationMessage:''
    },
    cubics:{
      element:'input',
      value:'',        
      config:{
          name:'cubics_input',
          type:'',          
          placeholder:'Enter vehicle motor volume',
          maxLength: '4'
                    
      },
      validation:{
          required:true
      },
      valid:false,
      touched: false,
      validationMessage:''
  },
      power:{
        element:'input',
        value:'',        
        config:{
            name:'power_input',
            type:'',          
            placeholder:'Enter vehicle motor power',
            maxLength: '3'
                      
        },
        validation:{
            required:true
        },
        valid:false,
        touched: false,
        validationMessage:''
    },
    drive:{
      element:'select',
      value:'',
      config:{
        name:'drive_input'
      },
      validation:{
        required:true
      },
      valid:false,
      touched:false,
      validationMessage:''
    },
    gear:{
      element:'select',
      value:'',
      config:{
        name:'gear_input'
      },
      validation:{
        required:true
      },
      valid:false,
      touched:false,
      validationMessage:''
    },
    lenght:{
      element:'input',
      value:'',        
      config:{
          name:'lenght_input',
          type:'',          
          placeholder:'Enter vehicle lenght cm',
          maxLength: '4'
                    
      },
      validation:{
          required:true
      },
      valid:false,
      touched: false,
      validationMessage:''
  },
  weight:{
    element:'input',
    value:'',        
    config:{
        name:'weight_input',
        type:'',          
        placeholder:'Enter vehicle weight Kg ',
        maxLength: '4'
                  
    },
    validation:{
        required:true
    },
    valid:false,
    touched: false,
    validationMessage:''
},
    }
  }
///brand field select
  generateOptionsBrand = () => {
    const brandArray = ['BMW', 'Audi','Mercedes', 'Toyota'];    
    
    return brandArray.map((value,id)=>(
      <option key={id} value={value}>{value}</option>
    ))
  }

  ///drive field select
  generateOptionsDrive = () => {    
    const driveArray = ['front', 'back','4x4'];    
    
    return driveArray.map((value,id)=>(
      <option key={id} value={value}>{value}</option>
    ))
  }
  ///Gear field select
  generateOptionsGear = () => {  
    const gearArray = ['auto', 'manual'];
    
    return gearArray.map((value,id)=>(
      <option key={id} value={value}>{value}</option>
    ))
  }

  updateForm = (element) => {
    const newFormData = { ...this.state.formData }
    const newElement = { ...newFormData[element.id] }

    newElement.value = element.event.target.value;

    ///Validation
    let validateData = validate(newElement);
        newElement.valid = validateData[0];
        newElement.validationMessage = validateData[1];

///if the field was touched
    if(element.blur){
      newElement.touched = element.blur
    }
///state
    newFormData[element.id] = newElement;
        this.setState({
            formData: newFormData
        })
  }

///Submit
submitForm = (event) => {
  event.preventDefault();

  let dataToSubmit = {};
  let formIsValid = true;

  for(let key in this.state.formData){
      formIsValid = this.state.formData[key].valid && formIsValid;
  }
  if(formIsValid){
      this.setState({loading:true});
      for(let key in this.state.formData){
          dataToSubmit[key] =  this.state.formData[key].value
      }
      /// console.log('Bingo', dataToSubmit);
     
      ///into firestore
    const sendNewCar = async () => {        
     const collectionRef = collection(db, "Cars");
     const payload = dataToSubmit;
     await addDoc(collectionRef, payload);
      };
    sendNewCar();


      setTimeout(() => {
          this.setState({loading:false});
          this.onSuccess();          
      }, 2000);

  } else {
      alert('Form is not valid')
  }
}

onSuccess = () => {
  let forDataCopy = {
      ...this.state.formData
  }

  for(let key in this.state.formData){
      forDataCopy[key].value = '';
      forDataCopy[key].valid = false;
      forDataCopy[key].touched = false;
      forDataCopy[key].validationMessage = '';
  }



  this.setState({formData: forDataCopy});
  alert('Thank You')
}
  render(){
    return (
      <>    
          <div className='container'>
              <form>
              
                <div className='form-group'>                
                    <label>Brand of car</label>                    
                    <FormFieldsRegistration
                      formData={this.state.formData.brand}
                      change={ (element) => this.updateForm(element)}
                      id='brand'
                    >                          
                          <option value=''>Select brand of auto</option>
                          {this.generateOptionsBrand()}                          
                    </FormFieldsRegistration>
                </div>
                <div className="form-group">
                            <label>Year of production</label>
                            <FormFieldsRegistration
                                formData={this.state.formData.year}
                                change={ (element) => this.updateForm(element) }
                                id="year"
                            />
                </div>
                <div className="form-group">
                            <label>Cubics</label>
                            <FormFieldsRegistration
                                formData={this.state.formData.cubics}
                                change={ (element) => this.updateForm(element) }
                                id="cubics"
                            />
                </div>

                <div className="form-group">
                            <label>Power</label>
                            <FormFieldsRegistration
                                formData={this.state.formData.power}
                                change={ (element) => this.updateForm(element) }
                                id="power"
                            />
                </div>
                <div className='form-group'>                
                    <label>Car's Drive</label>                    
                    <FormFieldsRegistration
                      formData={this.state.formData.drive}
                      change={ (element) => this.updateForm(element)}
                      id='drive'
                    >                          
                          <option value=''>Select auto's drive</option>
                          {this.generateOptionsDrive()}                          
                    </FormFieldsRegistration>
                </div><div className='form-group'>                
                    <label>Gear</label>                    
                    <FormFieldsRegistration
                      formData={this.state.formData.gear}
                      change={ (element) => this.updateForm(element)}
                      id='gear'
                    >                          
                          <option value=''>Select gear of auto</option>
                          {this.generateOptionsGear()}                          
                    </FormFieldsRegistration>
                </div>
                <div className="form-group">
                            <label>Auto's lenght</label>
                            <FormFieldsRegistration
                                formData={this.state.formData.lenght}
                                change={ (element) => this.updateForm(element) }
                                id="lenght"
                            />
                </div><div className="form-group">
                            <label>Weight</label>
                            <FormFieldsRegistration
                                formData={this.state.formData.weight}
                                change={ (element) => this.updateForm(element) }
                                id="weight"
                            />
                </div>

                <button
                            type="submit"
                            className="btn btn-primary"
                            onClick={ (event)=> this.submitForm(event) }
                            disabled={this.state.loading}
                np>
                Submit
                </button>

              </form>


          </div>
      </>

      
          
    )
  }
}

export default Registration;