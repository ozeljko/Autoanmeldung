import React, { Component} from 'react';
import FormFieldsRegistration from '../methodes/formFieldsRegistration';


class Registration extends Component {
  
  state = {
    formData: {
      brand:{
        element:'select',
        value:'',
        config:{
          name:'brand_input'
        },
        validation:{
          required:true
        },
        valid:false,
        touched:false,
        validationMessage:''
      },
      power:{
        element:'input',
        value:'',
        config:{
            name:'power_input',
            type:'number',          
            placeholder:'Enter your KS'
        },
        validation:{
            required:true
        },
        valid:false,
        touched: false,
        validationMessage:''
    },
    }
  }

  generateOptions = () => {
    const brandArray = ['BMW', 'Audi','Mercedes'];
    
    return brandArray.map((value,id)=>(
      <option key={id} value={value}>{value}</option>
    ))
  }

  updateForm = (element) => {
    const newFormData = { ...this.state.formData }
    const newElement = { ...newFormData[element.id] }

    newElement.value = element.event.target.value;

    newFormData[element.id] = newElement;
        this.setState({
            formData: newFormData
        })
  }
  render(){
    return (
      <>    
          <div className='container'>
              <form>
              
                <div className='form-group'>
                
                    <label>Brand of car</label>
                    
                    <FormFieldsRegistration
                      formData={this.state.formData.brand}
                      change={ (element) => this.updateForm(element)}
                      id='brand'
                    >                          
                          <option value=''>Select brand of auto</option>
                          {this.generateOptions()}
                          
                    </FormFieldsRegistration>

                </div>

                <div className="form-group">
                            <label>Power</label>
                            <FormFieldsRegistration
                                formData={this.state.formData.power}
                                change={ (element) => this.updateForm(element) }
                                id="power"
                            />
                </div>

              </form>


          </div>
      </>

      
          
    )
  }
}

export default Registration;