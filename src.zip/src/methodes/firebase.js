import firebase from 'firebase';
  
var firebaseConfig = {
  apiKey: "AIzaSyDnY4reWji6FU9S7W3WsucyrGxisqEV8Uw",
  authDomain: "autoanmeldung-project.firebaseapp.com",
  projectId: "autoanmeldung-project",
  storageBucket: "autoanmeldung-project.appspot.com",
  messagingSenderId: "439107695587",
  appId: "1:439107695587:web:3c0c7fa14e78a4613c66d6",
  measurementId: "G-NJM8VQNE10"
};

// Initialize Firebase
firebase.initializeApp(firebaseConfig);
var db = firebase.firestore();
  
export default db;



