import React from "react";

const FormFieldsRegistration = ({formData,change,id, children}) => {

    const showError = () => {
        let errorMessage = null;

        if(
            formData.validation &&
            !formData.valid &&
            formData.validationMessage
        ){
            errorMessage = (
                <div className="error-label">
                    {formData.validationMessage}
                </div>
            )
        }

        return errorMessage;
    }
    
    const renderContent = () => {
    let formContent = null;

    switch(formData.element){
        case('input'):
            formContent = (
                <>
                    <input 
                        {...formData.config}
                        value={formData.value}
                        className="form-control"
                        onChange={ (event) => change({event,id,blur:null}) }
                        ///if the field was touched change blur to true
                        onBlur={ (event) => change({event,id,blur:true}) }
                                                
                        />
                    {showError()}
                </>
            )

        break;
        case('select'):
        formContent = (
            <>
                <select
                   {...formData.config}
                   value={formData.value}
                   className="form-control"
                   onChange={ (event) => change({event,id}) }
                   
                >
                    {children}
                </select>
                {showError()}
            </>
        )
        break;
        default:
            formContent = null
    
    }
    return formContent;
}

return(
    <>{renderContent()}</>
)

}

export default FormFieldsRegistration;